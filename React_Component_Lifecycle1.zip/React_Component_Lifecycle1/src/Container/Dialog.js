
import React, { Component } from 'react';


class Dialog extends Component {

  constructor(props) {
    super(props);
  }

  componentWillUpdate() {
    console.log('Component is about to update...');
  }
  
  componentWillReceiveProps(nextProps) { 
    console.log(this.props, nextProps)
  }


  componentDidUpdate() {
    console.log("Component has updated")
  }
  
 
  render() {
    return <h1>{this.props.message}</h1>
  }
};



export default Dialog;
