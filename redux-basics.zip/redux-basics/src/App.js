import React, { Component } from 'react';

import Persons from './containers/Persons';

class App extends Component {
  render() {
    return (
      <div className="App">
        <ol>
          <li>This module doesn't use Local state in UI Component but instead uses Redux</li>
        </ol>
        <Persons />
      </div>
    );
  }
}
  
export default App;
