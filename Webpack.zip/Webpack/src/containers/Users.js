import React, { Component } from 'react';

class Users extends Component {
    render () {
        return (
            <div>
                <h1>Varsha's first webpack</h1>
                <p>Varsha demonstrates webpack basics</p>
            </div>
        );
    }
}

export default Users;