
import React, { Component } from 'react';



class Evencomponent extends Component {
  constructor(props) {
    super(props);
  }
  
  shouldComponentUpdate(nextProps, nextState) {
    console.log('Should I update?');
     
      if (nextProps.value % 2 === 0) {
        return true;
      }
      return false;
     
  }
  componentWillReceiveProps(nextProps) {
    console.log('Receiving new props...');
  }
  componentDidUpdate() {
    console.log('Component re-rendered.');
  }
  render() {
    return <h1>{this.props.value}</h1>
  }
};



export default Evencomponent;
